package com.company;

public class Main {
    public static void main(String[] args) {

        BioMetricAttendance bioMetricAttendance = BioMetricAttendance.getInstance();
        bioMetricAttendance.setUser("Areeb Ahmed");


        bioMetricAttendance.showMessage();
    }
}
