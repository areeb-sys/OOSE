package com.company;

class BioMetricAttendance
{
    private static BioMetricAttendance regst;
    private String user;
    private BioMetricAttendance()
    {
    }
    public static BioMetricAttendance getInstance()
    {
        if(regst==null)
            regst= new BioMetricAttendance();
        return regst;
    }
    public void showMessage(){
        System.out.printf("FA19-BSE-022 \n %s" ,getUser());
    }
    public void setUser(String user)
    {
        this.user = user;
    }
    public String getUser()
    {
        return user;
    }
}
